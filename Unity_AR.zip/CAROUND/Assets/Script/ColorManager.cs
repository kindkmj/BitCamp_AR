﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

[ExecuteInEditMode]

public class ColorManager : MonoBehaviour {

	public Color BG_001;
	public Color BG_002;
	public Color Spot_001;
	public Color Spot_002;
	public Color Icon_001;
	public Color Text_001;
	public Color Text_002;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

	



	
	}
}
