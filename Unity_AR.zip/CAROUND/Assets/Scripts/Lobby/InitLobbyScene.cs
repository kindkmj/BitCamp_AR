﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InitLobbyScene : MonoBehaviour
{
    //로비씬 진입시 본인의 차량이 보여지게 됨.
    //
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
